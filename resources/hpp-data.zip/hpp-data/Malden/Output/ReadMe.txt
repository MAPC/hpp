Notes on the files:

Population by Age and Gender (2012-2016) also has the number for total populations for each municipality.

Households by Age 2012-2016 data does not exist as far as I can tell. 
We do have numbers for households by age for 2010 and projections for 2020 and 2030.

Total number of Households for ACS 2012-2016 are available in Households with Seniors (2012-2016). 
As far as Households by Age for ACS years, the table Households with Seniors by Household Type. 

The most recent numbers for Household Type by Household Income is only available for 2011-2015 This CHAS data sourced from ACS. 
The same for Household type by Cost Burdened Households 2011-2015, which is also CHAS Data sourced from ACS. 

The margins of error for Housing by year Built (ACS 2012-16) data is unusually high. Keep that in mind.

The scripts for these files can all be found in. They have been updated to connect to the new server:

K:\DataServices\Projects\Current_Projects\Housing_Production_Plans\_all_munis_RScripts


Please Note the Data sources. Some data comes from Census 2010 and others from ACS 2012-2016, ACS 2011-2015 & CHAS, depending on what's available. 
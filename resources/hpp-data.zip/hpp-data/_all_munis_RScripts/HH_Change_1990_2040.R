#enter town name here:
muni <- ("'Malden', 'Everett', 'Lynn', 'Quincy', 'Revere','Salem','Somerville'")
years <- '2012-16'
toupper(muni)

#enter file name with extension here:
outtable <- paste("HHbyAge_1990_2040.csv")
outtablepath <- "K:/DataServices/Projects/Current_Projects/Housing_Production_Plans/Malden HPP/Data/Output/"

#read data in from SDE
library(RPostgreSQL)
drv = dbDriver("PostgreSQL")
ch.ds = dbConnect(drv, host='10.10.10.240', port='5432', dbname='ds', user='viewer', password='mapcview451')

sqlquery <- paste("select muni_id, municipal,hh_90, hh_00, hh_10, hh_20_sq, hh_30_sq, hh_20_sr, hh_30_sr, hh_40_sr
                  from tabular.hous_projections_hh_m WHERE municipal IN (" , toupper(muni),
                  ")", sep = "")

#create data frame
sqlquery <- paste("select muni_id, municipal,
                  coha,
                  age_group,
                  hhest_10,
                  hh_20_sq,
                  hh_30_sq,
                  hh_20_sr,
                  hh_30_sr, hh_40_sr from tabular.hous_projections_hh_by_age_m WHERE municipal IN (" , toupper(muni),
                  ")", sep = "")

#Fetch all observations and write to file
rs <- dbSendQuery(ch.ds,sqlquery)
m<- fetch(rs, n=-1)

names(m) <- c("Municipal ID", "Municipality",
              "Households in 1990",
              "Households in 2010",
              "Households in 2010",
              "Households in 2020 based on Status Quo scenario",
              "Households in 2030 based on Status Quo scenario",
              "Households in 2020 based on Stronger Region scenario",
              "Households in 2030 based on Stronger Region scenario",
              "Households in 2040 based on Stronger Region scenario")

#export data as spreadsheet
setwd(outtablepath)
write.csv(m, outtable, row.names = FALSE)
#enter town name here:
muni <- ("'Malden', 'Everett', 'Lynn', 'Quincy', 'Revere','Salem','Somerville'")

#enter file name with extension here:
outtable <- paste("PopulationProjections.csv")
outtablepath <- "K:/DataServices/Projects/Current_Projects/Housing_Production_Plans/Malden HPP/Data/Output/"

#read data in from SDE
library(RPostgreSQL)
drv = dbDriver("PostgreSQL")
ch.ds = dbConnect(drv, host='10.10.10.240', port='5432', dbname='ds', user='viewer', password='mapcview451')

#create data frame
sqlquery <- paste("select*
                  from tabular.demo_projections_pop_m WHERE municipal IN (" , muni,
                  ")", sep = "")

rs <- dbSendQuery(ch.ds,sqlquery)
m<- fetch(rs, n=-1)


names(m) <- c("Seq_ID", "Municipal ID", "Municipality",
              "Projections Source",
              "Population 1990",
              "Population 2000",
              "Household Population 2000",
              "Group Quarters Population 2000",
              "Population 2010",
              "Household Population 2010",
              "Group Quarters Population 2010",
              "Population 2020 (Status Quo)",
              "Household Population 2020 (Status Quo)",
              "Group Quarters Population 2020 (Status Quo)",
              "Population 2030 (Status Quo)",
              "Household Population 2030 (Status Quo)",
              "Group Quarters Population 2030 (Status Quo)",
              "Population 2020 (Stronger Region)",
              "Household Population 2020 (Stronger Region)",
              "Group Quarters Population 2020 (Stronger Region)",
              "Population 2030 (Stronger Region)",
              "Household Population 2030 (Stronger Region)",
              "Group Quarters Population 2030 (Stronger Region)",
              "Population 2040 (Stronger Region)",
              "Household Population 2040 (Stronger Region)"
              
              
)
              

#export data as spreadsheet
setwd(outtablepath)
write.csv(m, outtable, row.names = FALSE)


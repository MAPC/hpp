#enter town name here:
muni <- ("'Malden', 'Everett', 'Lynn', 'Quincy', 'Revere','Salem','Somerville'")
years <- '2012-16'

#enter file name with extension here:
outtable <- paste("HHIncomebyAge_2012-2016.csv")
outtablepath <- "K:/DataServices/Projects/Current_Projects/Housing_Production_Plans/Malden HPP/Data/Output/"


#read data in from SDE
library(RPostgreSQL)
drv = dbDriver("PostgreSQL")
ch.ds = dbConnect(drv, host='10.10.10.240', port='5432', dbname='ds', user='viewer', password='mapcview451')

#create data frame for medianhhincome
sqlquery <- paste("select * from tabular.b19037_hh_income_by_age_acs_m WHERE municipal IN (" , muni,
                  ") AND acs_year = '2012-16'", sep = "")

#Fetch all observations and write to file
rs <- dbSendQuery(ch.ds,sqlquery)
m<- fetch(rs, n=-1)

names(m) <- c("Seq_ID",
              "Municipal ID",
              "Municipaity",
              "Census Geographic Level ID",
              "Census Logical Record Number",
              "ACS Years",
              "Households",
              "Household; Margin of Error",
              "Householder under 25 years",
              "Householder under 25 years; Margin of Error",
              "Householder under 25 years with Income under $20,000",
              "Householder under 25 years with Income under $20,000; Margin of Error",
              "Householder under 25 years with Income $20,000-$39,999",
              "Householder under 25 years with Income $20,000-$39,999; Margin of Error",
              "Householder under 25 years with Income $40,000-$59,999",
              "Householder under 25 years with Income $40,000-$59,999; Margin of Error",
              "Householder under 25 years with Income $60,000-$74,999",
              "Householder under 25 years with Income $60,000-$74,999; Margin of Error",
              "Householder under 25 years with Income $75,000-$99,999",
              "Householder under 25 years with Income $75,000-$99,999; Margin of Error",
              "Householder under 25 years with Income $100,000 or more",
              "Householder under 25 years with Income $100,000 or more; Margin of Error",
              "Householder 25-44 years",
              "Householder 25-44 years; Margin of Error",
              "Householder 25-44 years with Income under $20,000",
              "Householder 25-44 years with Income under $20,000; Margin of Error",
              "Householder 25-44 years with Income $20,000-$39,999",
              "Householder 25-44 years with Income $20,000-$39,999; Margin of Error",
              "Householder 25-44 years with Income $40,000-$59,999",
              "Householder 25-44 years with Income $40,000-$59,999; Margin of Error",
              "Householder 25-44 years with Income $60,000-$74,999",
              "Householder 25-44 years with Income $60,000-$74,999; Margin of Error",
              "Householder 25-44 years with Income $75,000-$99,999",
              "Householder 25-44 years with Income $75,000-$99,999; Margin of Error",
              "Householder 25-44 years with Income $100,000 or more",
              "Householder 25-44 years with Income $100,000 or more; Margin of Error",
              "Householder 45-64 years",
              "Householder 45-64 years; Margin of Error",
              "Householder 45-64 years with Income under $20,000",
              "Householder 45-64 years with Income under $20,000; Margin of Error",
              "Householder 45-64 years with Income $20,000-$39,999",
              "Householder 45-64 years with Income $20,000-$39,999; Margin of Error",
              "Householder 45-64 years with Income $40,000-$59,999",
              "Householder 45-64 years with Income $40,000-$59,999; Margin of Error",
              "Householder 45-64 years with Income $60,000-$74,999",
              "Householder 45-64 years with Income $60,000-$74,999; Margin of Error",
              "Householder 45-64 years with Income $75,000-$99,999",
              "Householder 45-64 years with Income $75,000-$99,999; Margin of Error",
              "Householder 45-64 years with Income $100,000 or more",
              "Householder 45-64 years with Income $100,000 or more; Margin of Error",
              "Householder 65+ years",
              "Householder 65+ years; Margin of Error",
              "Householder 65+ years with Income under $20,000",
              "Householder 65+ years with Income under $20,000; Margin of Error",
              "Householder 65+ years with Income $20,000-$39,999",
              "Householder 65+ years with Income $20,000-$39,999; Margin of Error",
              "Householder 65+ years with Income $40,000-$59,999",
              "Householder 65+ years with Income $40,000-$59,999; Margin of Error",
              "Householder 65+ years with Income $60,000-$74,999",
              "Householder 65+ years with Income $60,000-$74,999; Margin of Error",
              "Householder 65+ years with Income $75,000-$99,999",
              "Householder 65+ years with Income $75,000-$99,999; Margin of Error",
              "Householder 65+ years with Income $100,000 or more",
              "Householder 65+ years with Income $100,000 or more; Margin of Error",
              "% Householder under 25 years",
              "% Householder under 25 years; Margin of Error",
              "% Householder under 25 years with Income under $20,000",
              "% Householder under 25 years with Income under $20,000; Margin of Error",
              "% Householder under 25 years with Income $20,000-$39,999",
              "% Householder under 25 years with Income $20,000-$39,999; Margin of Error",
              "% Householder under 25 years with Income $40,000-$59,999",
              "% Householder under 25 years with Income $40,000-$59,999; Margin of Error",
              "% Householder under 25 years with Income $60,000-$74,999",
              "% Householder under 25 years with Income $60,000-$74,999; Margin of Error",
              "% Householder under 25 years with Income $75,000-$99,999",
              "% Householder under 25 years with Income $75,000-$99,999; Margin of Error",
              "% Householder under 25 years with Income $100,000 or more",
              "% Householder under 25 years with Income $100,000 or more; Margin of Error",
              "% Householder 25-44 years",
              "% Householder 25-44 years; Margin of Error",
              "% Householder 25-44 years with Income under $20,000",
              "% Householder 25-44 years with Income under $20,000; Margin of Error",
              "% Householder 25-44 years with Income $20,000-$39,999",
              "% Householder 25-44 years with Income $20,000-$39,999; Margin of Error",
              "% Householder 25-44 years with Income $40,000-$59,999",
              "% Householder 25-44 years with Income $40,000-$59,999; Margin of Error",
              "% Householder 25-44 years with Income $60,000-$74,999",
              "% Householder 25-44 years with Income $60,000-$74,999; Margin of Error",
              "% Householder 25-44 years with Income $75,000-$99,999",
              "% Householder 25-44 years with Income $75,000-$99,999; Margin of Error",
              "% Householder 25-44 years with Income $100,000 or more",
              "% Householder 25-44 years with Income $100,000 or more; Margin of Error",
              "% Householder 45-64 years",
              "% Householder 45-64 years; Margin of Error",
              "% Householder 45-64 years with Income under $20,000",
              "% Householder 45-64 years with Income under $20,000; Margin of Error",
              "% Householder 45-64 years with Income $20,000-$39,999",
              "% Householder 45-64 years with Income $20,000-$39,999; Margin of Error",
              "% Householder 45-64 years with Income $40,000-$59,999",
              "% Householder 45-64 years with Income $40,000-$59,999; Margin of Error",
              "% Householder 45-64 years with Income $60,000-$74,999",
              "% Householder 45-64 years with Income $60,000-$74,999; Margin of Error",
              "% Householder 45-64 years with Income $75,000-$99,999",
              "% Householder 45-64 years with Income $75,000-$99,999; Margin of Error",
              "% Householder 45-64 years with Income $100,000 or more",
              "% Householder 45-64 years with Income $100,000 or more; Margin of Error",
              "% Householder 65+ years",
              "% Householder 65+ years; Margin of Error",
              "% Householder 65+ years with Income under $20,000",
              "% Householder 65+ years with Income under $20,000; Margin of Error",
              "% Householder 65+ years with Income $20,000-$39,999",
              "% Householder 65+ years with Income $20,000-$39,999; Margin of Error",
              "% Householder 65+ years with Income $40,000-$59,999",
              "% Householder 65+ years with Income $40,000-$59,999; Margin of Error",
              "% Householder 65+ years with Income $60,000-$74,999",
              "% Householder 65+ years with Income $60,000-$74,999; Margin of Error",
              "% Householder 65+ years with Income $75,000-$99,999",
              "% Householder 65+ years with Income $75,000-$99,999; Margin of Error",
              "% Householder 65+ years with Income $100,000 or more",
              "% Householder 65+ years with Income $100,000 or more; Margin of Error"
              
  
)

#export data as spreadsheet
setwd(outtablepath)
write.csv(m, outtable, row.names = FALSE)
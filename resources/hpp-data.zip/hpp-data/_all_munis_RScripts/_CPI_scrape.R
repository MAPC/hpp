library(rvest)
library(dplyr)
#Scrape CPI
url <- "http://www.usinflationcalculator.com/inflation/consumer-price-index-and-annual-percent-changes-from-1913-to-2008/"
results <- url %>%
html() %>%
  
# Copy xpath of table in webpage using Inspect Element
html_nodes(xpath='//*[@id="post-17"]/div/div[1]/table') %>%
html_table()
results <- results[[1]]
head(results)

names(results)<- c(results[2,])
results <- results[-2,]
results <- results[-1,]

write.csv(results, "K:/DataServices/Projects/Current_Projects/Housing_Production_Plans/_all_munis_RScripts/CPI.csv")

#enter town name here:
muni <- ("'Malden', 'Everett', 'Lynn', 'Quincy', 'Revere','Salem','Somerville'")
years <- '2012-16'

#enter file name with extension here:
outtable <- paste("HH_Seniors_2012_2016.csv")
outtablepath <- "K:/DataServices/Projects/Current_Projects/Housing_Production_Plans/Malden HPP/Data/Output/"

#read data in from SDE
library(RPostgreSQL)
drv = dbDriver("PostgreSQL")
ch.ds = dbConnect(drv, host='10.10.10.240', port='5432', dbname='ds', user='viewer', password='mapcview451')


#create data frame 
sqlquery <- paste("select muni_id, municipal, acs_year, hh, hh_me, hh65o, hh65ome, hh1, hh1me, famhh, famhhme, nonfam, nonfamme, hh65o_p, hh65omep, hh1_p, hh1mep,
                  famhh_p, famhhmep, nonfam_p, nonfammep from tabular.b11007_hh_with_seniors_acs_m  WHERE municipal IN (" , muni,
                  ") AND acs_year = '2012-16'", sep = "")

rs <- dbSendQuery(ch.ds,sqlquery)
m<- fetch(rs, n=-1)

names(m) <- c("Muni ID", "Municipality", "ACS Years", "Total Households", "Households Margin of Error", "Households with Seniors 65 and Over",
              "Households with Seniors 65 and over; MoE",
              "Senior person Living Alone", "Senior Person Living alone Margin of error", "Family Households with Seniors", 
              "Family Households with Seniors; MoE",
              "Nonfamily Households with Seniors","Nonfamily Households with Seniors; MoE", "% Households with senior(s)", 
              "% Households with senior(s); Margin of Error","% Senior living alone",
              "% Senior living alone; Margin of Error",
              "% Family Households with senior(s)",
              "% Family Households with senior(s); Margin of Error",
              "% Non-Family Households with senior(s)",
              "% Non-Family Households with senior(s); Margin of Error"
)

#export data as spreadsheet
setwd(outtablepath)
write.csv(m, outtable, row.names = FALSE)







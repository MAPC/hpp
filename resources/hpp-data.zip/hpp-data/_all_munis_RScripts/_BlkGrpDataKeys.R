#Finding Block Group Geographies
#enter town name here:
muni <- ("'Malden'")

#enter file name with extension here:
outtable <- paste("Malden_BlockGroups.csv")
outtablepath <- "K:/DataServices/Projects/Current_Projects/Housing_Production_Plans/Malden HPP/Data/Output/"

#read data in from SDE
library(RPostgreSQL)
drv = dbDriver("PostgreSQL")
ch.ds = dbConnect(drv, host='10.10.10.240', port='5432', dbname='ds', user='viewer', password='mapcview451')

#create data frame
sqlquery <- paste("select *
                  from tabular._datakeys_bg10 WHERE municipal IN (" , muni,
                  ") ", sep = "")

#Fetch all observations
rs <- dbSendQuery(ch.ds,sqlquery)
m<- fetch(rs, n=-1)

#export data as spreadsheet
setwd(outtablepath)
write.csv(m, outtable, row.names = FALSE)

####################################################
### END OF SCRIPT
####################################################

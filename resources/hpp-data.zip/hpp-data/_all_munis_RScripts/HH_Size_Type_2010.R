#enter town name here:
muni <- ("'Malden', 'Everett', 'Lynn', 'Quincy', 'Revere','Salem','Somerville'")
years <- '2012-16'

#enter file name with extension here:
outtable <- paste("HH_Size_Type_2010.csv")
outtablepath <- "K:/DataServices/Projects/Current_Projects/Housing_Production_Plans/Malden HPP/Data/Output/"

#read data in from SDE
library(RPostgreSQL)
drv = dbDriver("PostgreSQL")
ch.ds = dbConnect(drv, host='10.10.10.240', port='5432', dbname='ds', user='viewer', password='mapcview451')


#create data frame 
sqlquery <- paste("select * from tabular.census2010_p28_hh_by_hhsize_m  WHERE municipal IN (" , muni,
                  ") AND years = '2010'", sep = "")

rs <- dbSendQuery(ch.ds,sqlquery)
m<- fetch(rs, n=-1)

names(m) <- c("Municipal ID",
              "Municipality",
              "Census Logical Record Number",
              "Year",
              "Households 2010",
              "1-person Households",
              "2-person Households",
              "3-person Households",
              "4-person Households",
              "5-person Households",
              "6-person Households",
              "7-person Households",
              " Family households",
              "2-person Family Households",
              "3-person Family Households",
              "4-person Family Households",
              "5-person Family Households",
              "6-person Family Households",
              "7-person Family Households",
              " Non-Family Households",
              "2-person Non-Family Households",
              "3-person Non-Family Households",
              "4-person Non-Family Households",
              "5-person Non-Family Households",
              "6-person Non-Family Households",
              "7-person Non-Family Households",
              "% 1-person Households",
              "% 2-person Households",
              "% 3-person Households",
              "% 4-person Households",
              "% 5-person Households",
              "% 6-person Households",
              "% 7-person Households",
              "% Family households",
              "% 2-person Family Households",
              "% 3-person Family Households",
              "% 4-person Family Households",
              "% 5-person Family Households",
              "% 6-person Family Households",
              "% 7-person Family Households",
              "% Non-Family households",
              "% 2-person Non-Family Households",
              "% 3-person Non-Family Households",
              "% 4-person Non-Family Households",
              "% 5-person Non-Family Households",
              "% 6-person Non-Family Households",
              "% 7-person Non-Family Households"
              
)

#export data as spreadsheet
setwd(outtablepath)
write.csv(m, outtable, row.names = FALSE)







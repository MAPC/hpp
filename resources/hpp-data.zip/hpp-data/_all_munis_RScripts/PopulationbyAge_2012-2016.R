#enter town name here:
muni <- ("'Malden', 'Everett', 'Lynn', 'Quincy', 'Revere','Salem','Somerville'")

years <- '2012-16'

#enter file name with extension here:
outtable <- paste("PopbyAge_2012_2016.csv")
outtablepath <- "K:/DataServices/Projects/Current_Projects/Housing_Production_Plans/Malden HPP/Data/Output/"

#read data in from SDE
library(RPostgreSQL)
drv = dbDriver("PostgreSQL")
ch.ds = dbConnect(drv, host='10.10.10.240', port='5432', dbname='ds', user='viewer', password='mapcview451')


#create data frame
sqlquery <- paste("select 
                  muni_id,
                  municipal,
                  acs_year,
                  pop,
                  popm,
                  pop_u5,
                  pop_u5m,
                  pop_5_9,
                  pop_5_9m,
                  pop1014,
                  pop1014m,
                  pop1517,
                  pop1517m,
                  pop1819,
                  pop1819m,
                  pop20,
                  pop20m,
                  pop21,
                  pop21m,
                  pop2224,
                  pop2224m,
                  pop2529,
                  pop2529m,
                  pop3034,
                  pop3034m,
                  pop3539,
                  pop3539m,
                  pop4044,
                  pop4044m,
                  pop4549,
                  pop4549m,
                  pop5054,
                  pop5054m,
                  pop5559,
                  pop5559m,
                  pop6061,
                  pop6061m,
                  pop6264,
                  pop6264m,
                  pop6566,
                  pop6566m,
                  pop6769,
                  pop6769m,
                  pop7074,
                  pop7074m,
                  pop7579,
                  pop7579m,
                  pop8084,
                  pop8084m,
                  pop85o,
                  pop85om
                  from tabular.b01001_population_by_age_gender_acs_m WHERE municipal IN (" , muni,
                  ") AND acs_year = '2012-16'", sep = "")

#Fetch all observations and write to file
rs <- dbSendQuery(ch.ds,sqlquery)
m <- fetch(rs, n=-1)


#export data as spreadsheet
setwd(outtablepath)
write.csv(m, outtable, row.names = FALSE)


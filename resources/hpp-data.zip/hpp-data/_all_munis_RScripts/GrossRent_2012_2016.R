#enter town name here:
muni <- ("'Malden', 'Everett', 'Lynn', 'Quincy', 'Revere','Salem','Somerville'")
years <- '2012-16'

#enter file name with extension here:
outtable <- paste("GrossRent_2012-2016.csv")
outtablepath <- "K:/DataServices/Projects/Current_Projects/Housing_Production_Plans/Malden HPP/Data/Output/"


#read data in from SDE
library(RPostgreSQL)
drv = dbDriver("PostgreSQL")
ch.ds = dbConnect(drv, host='10.10.10.240', port='5432', dbname='ds', user='viewer', password='mapcview451')

#create data frame for medianhhincome
sqlquery <- paste("select muni_id, municipal, acs_year, r_occ, r_occm, med_c_r, med_c_rm, cashrnt, cashrntm
                  from tabular.b25063_b25064_b25065_rent_acs_m WHERE municipal IN (" , muni,
                  ") AND acs_year = '2012-16'", sep = "")

#Fetch all observations and write to file
rs <- dbSendQuery(ch.ds,sqlquery)
m<- fetch(rs, n=-1)

names(m) <- c("Muni ID", "Municipality", "ACS Years",
              "Renter-occupied Housing Units",
              "Renter-occupied Housing Units; Margin of Error",
              "Median Gross Rent",
              "Median Gross Rent; Margin of Error",
              "Renter-occupied Housing Units paying cash rent",
              "Renter-occupied Housing Units paying cash rent; Margin of Error"
              )

#export data as spreadsheet
setwd(outtablepath)
write.csv(m, outtable, row.names = FALSE)
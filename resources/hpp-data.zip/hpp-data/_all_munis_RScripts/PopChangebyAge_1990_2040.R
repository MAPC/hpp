#enter town name here:
muni <- ("'Malden', 'Everett', 'Lynn', 'Quincy', 'Revere','Salem','Somerville'")
years <- '2012-16'

#enter file name with extension here:
outtable <- paste("PopChangebyAge_1990_2040.csv")
outtablepath <- "K:/DataServices/Projects/Current_Projects/Housing_Production_Plans/Malden HPP/Data/Output/"

#read data in from SDE
library(RPostgreSQL)
drv = dbDriver("PostgreSQL")
ch.ds = dbConnect(drv, host='10.10.10.240', port='5432', dbname='ds', user='viewer', password='mapcview451')

#create data frame
sqlquery <- paste("select muni_id, municipal,
                  proj_src,
                  coha,
                  age_group,
                  pop_90,
                  pop_00,
                  pop_10,
                  pop_20sq,
                  pop_30sq,
                  pop_20sr,
                  pop_30sr,
                  pop_40sr
                  from tabular.demo_projections_pop_by_age_m WHERE municipal IN (" , muni,
                  ")", sep = "")

#Fetch all observations and write to file
rs <- dbSendQuery(ch.ds,sqlquery)
m<- fetch(rs, n=-1)


names(m) <- c("Municipal ID", "Municipality",
              "Projections Source",
              "Cohort ID",
              "Age Groups",
              "Population 1990",
              "Population 2000",
              "Population 2010",
              "Population 2020 (Status Quo)",
              "Population 2030 (Status Quo)",
              "Population 2020 (Stronger Region)",
              "Population 2030 (Stronger Region)",
              "Population 2040 (Stronger Region)")


#export data as spreadsheet
setwd(outtablepath)
write.csv(m, outtable, row.names = FALSE)


#enter town name here:
muni <- ("'Malden', 'Everett', 'Lynn', 'Quincy', 'Revere','Salem','Somerville'")
years <- '2012-16'

#enter file name with extension here:
outtable <- paste("HH_type_by_CostBurdenedStatus_2011-2015.csv")
outtablepath <- "K:/DataServices/Projects/Current_Projects/Housing_Production_Plans/Malden HPP/Data/Output/"

#read data in from SDE
library(RPostgreSQL)
drv = dbDriver("PostgreSQL")
ch.ds = dbConnect(drv, host='10.10.10.240', port='5432', dbname='ds', user='viewer', password='mapcview451')

#create data frame
sqlquery <- paste("select * from tabular.hous_hh_type_by_cb_chas_m WHERE municipal IN (" , muni,
                  ") AND acs_year = '2011-15'", sep = "")

#Fetch all observations and write to file
rs <- dbSendQuery(ch.ds,sqlquery)
m<- fetch(rs, n=-1)

names(m) <- c("Seq_ID",
              "Municipal ID",
              "Municipality",
              "Total Occupied housing units",
              "Total Occupied housing units Margin of Error",
              "Elderly family Households (2 persons, with either or both age 62 or over) ",
              "Elderly family Households (2 persons, with either or both age 62 or over) Margin of Error",
              "Elderly family Households that are Not Cost Burdened",
              "Elderly family Households that are Not Cost Burdened Margin of Error",
              "Elderly family Households that are Cost Burdened",
              "Elderly family Households that are Cost Burdened Margin of Error",
              "Elderly family Households that are Severely Cost Burdened",
              "Elderly family Households that are Severely Cost Burdened Margin of Error",
              "Elderly non-family Households that are Not Cost Burdened",
              "Elderly non-family Households that are Not Cost Burdened Margin of Error",
              "Elderly non-family Households that are Cost Burdened",
              "Elderly non-family Households that are Cost Burdened Margin of Error",
              "Elderly non-family Households that are Severely Cost Burdened",
              "Elderly non-family Households that are Severely Cost Burdened Margin of Error",
              "Elderly non-family Households that are Not Cost Burdened",
              "Elderly non-family Households that are Not Cost Burdened Margin of Error",
              "Small family Households (2 persons, neither person 62 years or over, or 3 or 4 persons) ",
              "Small family Households (2 persons, neither person 62 years or over, or 3 or 4 persons) Margin of Error",
              "Small family Households that are Not Cost Burdened",
              "Small family Households that are Not Cost Burdened Margin of Error",
              "Small family Households that are Cost Burdened",
              "Small family Households that are Cost Burdened Margin of Error",
              "Small family Households that are Severely Cost Burdened",
              "Small family Households that are Severely Cost Burdened Margin of Error",
              "Large family Households (5 or more persons) ",
              "Large family Households (5 or more persons) Margin of Error",
              "Large family Households that are Not Cost Burdened",
              "Large family Households that are Not Cost Burdened Margin of Error",
              "Large family Households that are Cost Burdened",
              "Large family Households that are Cost Burdened Margin of Error",
              "Large family Households that are Severely Cost Burdened",
              "Large family Households that are Severely Cost Burdened Margin of Error",
              "Other Household types (non-elderly non-family) ",
              "Other Household types (non-elderly non-family) Margin of Error",
              "Other Household types that are Not Cost Burdened",
              "Other Household types that are Not Cost Burdened Margin of Error",
              "Other Household types that are Cost Burdened",
              "Other Household types that are Cost Burdened Margin of Error",
              "Other Household types that are Severely Cost Burdened",
              "Other Household types that are Severely Cost Burdened Margin of Error",
              "% Elderly family Households (2 persons, with either or both age 62 or over) ",
              "% Elderly family Households (2 persons, with either or both age 62 or over) Margin of Error",
              "% Elderly family Households that are Not Cost Burdened",
              "% Elderly family Households that are Not Cost Burdened Margin of Error",
              "% Elderly family Households that are Cost Burdened",
              "% Elderly family Households that are Cost Burdened Margin of Error",
              "% Elderly family Households that are Severely Cost Burdened",
              "% Elderly family Households that are Severely Cost Burdened Margin of Error",
              "% Elderly non-family Households that are Not Cost Burdened",
              "% Elderly non-family Households that are Not Cost Burdened Margin of Error",
              "% Elderly non-family Households that are Cost Burdened",
              "% Elderly non-family Households that are Cost Burdened Margin of Error",
              "% Elderly non-family Households that are Severely Cost Burdened",
              "% Elderly non-family Households that are Severely Cost Burdened Margin of Error",
              "% Elderly non-family Households that are Not Cost Burdened",
              "% Elderly non-family Households that are Not Cost Burdened Margin of Error",
              "% Small family Households (2 persons, neither person 62 years or over, or 3 or 4 persons) ",
              "% Small family Households (2 persons, neither person 62 years or over, or 3 or 4 persons) Margin of Error",
              "% Small family Households that are Not Cost Burdened",
              "% Small family Households that are Not Cost Burdened Margin of Error",
              "% Small family Households that are Cost Burdened",
              "% Small family Households that are Cost Burdened Margin of Error",
              "% Small family Households that are Severely Cost Burdened",
              "% Small family Households that are Severely Cost Burdened Margin of Error",
              "% Large family Households (5 or more persons) ",
              "% Large family Households (5 or more persons) Margin of Error",
              "% Large family Households that are Not Cost Burdened",
              "% Large family Households that are Not Cost Burdened Margin of Error",
              "% Large family Households that are Cost Burdened",
              "% Large family Households that are Cost Burdened Margin of Error",
              "% Large family Households that are Severely Cost Burdened",
              "% Large family Households that are Severely Cost Burdened Margin of Error",
              "% Other Household types (non-elderly non-family) ",
              "% Other Household types (non-elderly non-family) Margin of Error",
              "% Other Household types that are Not Cost Burdened",
              "% Other Household types that are Not Cost Burdened Margin of Error",
              "% Other Household types that are Cost Burdened",
              "% Other Household types that are Cost Burdened Margin of Error",
              "% Other Household types that are Severely Cost Burdened",
              "% Other Household types that are Severely Cost Burdened Margin of Error"
              
              
  
)

#export data as spreadsheet
setwd(outtablepath)
write.csv(m, outtable, row.names = FALSE)
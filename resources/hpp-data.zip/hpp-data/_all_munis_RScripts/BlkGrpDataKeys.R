#enter town name here:
muni <- ("'Beverly', 'Danvers', 'Essex', 'Gloucester', 'Hamilton', 'Ipswich', 'Lynn', 'Manchester', 'Marblehead', 'Middleton', 'Nahant', 'Peabody', 'Rockport', 'Salem', 'Saugus', 'Swampscott', 'Topsfield','Wenham'")


#enter file name with extension here:
outtable <- paste("BlockGrpCodes.csv")

#read data in from SDE
library(RPostgreSQL)
drv = dbDriver("PostgreSQL")
ch.ds = dbConnect(drv, host='10.10.10.240', port='5432', dbname='ds', user='dsviewer', password='dsview933')
ch.gisdata = dbConnect(drv, host='10.10.10.240', port='5432', dbname='gisdata', user='dsviewer', password='dsview933')

#create data frame
sqlquery <- paste("select *
                  from tabular._datakeys_bg10 WHERE municipal IN (" , muni,
                  ") ", sep = "")

m <- fetch(dbSendQuery(ch.ds, sqlquery, n = -1))

#export data as spreadsheet
outtablepath <- paste("K:/DataServices/Projects/Current_Projects/Transportation/NorthShoreCoalitionVisioning/Data/Tabular/", outtable, sep = '')
write.csv(m, outtablepath)

#enter town name here:
muni <- ("'Malden', 'Everett', 'Lynn', 'Quincy', 'Revere','Salem','Somerville'")


#enter file name with extension here:
outtable <- paste("SchoolEnrollment.csv")
outtablepath <- "K:/DataServices/Projects/Current_Projects/Housing_Production_Plans/Malden HPP/Data/Output/"

#read data in from SDE
library(RPostgreSQL)
drv = dbDriver("PostgreSQL")
ch.ds = dbConnect(drv, host='10.10.10.240', port='5432', dbname='ds', user='viewer', password='mapcview451')


#create data frame 
sqlquery <- paste("select * from tabular.educ_enrollment_by_year_districts  WHERE district IN (" , muni,
                  ")", sep = "")

rs <- dbSendQuery(ch.ds,sqlquery)
m<- fetch(rs, n=-1)

names(m) <- c("Seq ID",
              "School District ID",
              "School District Name",
              "School Year",
              "Total Enrollment",
              "Enrollment in Pre-Kindergarden",
              "Enrollment in Kindergarden",
              "Enrollment in Grade 1",
              "Enrollment in Grade 2",
              "Enrollment in Grade 3",
              "Enrollment in Grade 4",
              "Enrollment in Grade 5",
              "Enrollment in Grade 6",
              "Enrollment in Grade 7",
              "Enrollment in Grade 8",
              "Enrollment in Grade 9",
              "Enrollment in Grade 10",
              "Enrollment in Grade 11",
              "Enrollment in Grade 12",
              "Enrollment in Special Education",
              "African American or Black Enrollment",
              "% African American or Black Enrollment",
              "Asian Enrollment",
              "% Asian Enrollment",
              "Hispanic or Latino Enrollment",
              "% Hispanic or Latino Enrollment",
              "White Enrollment",
              "% White Enrollment",
              "Native American Enrollment",
              "% Native American Enrollment",
              "Native Hawaiian or Other Pacific Islander Enrollment",
              "% Native Hawaiian or Other Pacific Islander Enrollment",
              "Multi-Race Non-Hispanic Enrollment",
              "% Multi-Race Non-Hispanic Enrollment",
              "Male Enrollment",
              "% Male Enrollment",
              "Female Enrollment",
              "% Female Enrollment",
              "First Language not English Enrollment",
              "% First Language not English Enrollment",
              "Limited English Proficient Enrollment",
              "% Limited English Proficient Enrollment",
              "Students with Disabilites Enrollment",
              "% Students with Disabilites Enrollment",
              "Low-income Enrollment",
              "% Low-income Enrollment",
              "Students Eligible for Free Lunch Enrollment",
              "% Students Eligible for Free Lunch Enrollment",
              "Students eligible for reduced price lunch Enrollment",
              "% Students eligible for reduced price lunch Enrollment",
              "High Needs Enrollment",
              "% High Needs Enrollment",
              "Economically Disadvantaged",
              "% Economically Disadvantaged Enrollment",
              "In MAPC? 1=Yes;0=No"
)

#export data as spreadsheet
setwd(outtablepath)
write.csv(m, outtable, row.names = FALSE)







#enter town name here:
muni <- ("'Malden', 'Everett', 'Lynn', 'Quincy', 'Revere','Salem','Somerville'")

#enter file name with extension here:
outtable <- paste("HouseSalesPrices_2000_2017_AdjustedforInflation.csv")
outtablepath <- "K:/DataServices/Projects/Current_Projects/Housing_Production_Plans/Malden HPP/Data/Output/"

#read data in from SDE
library(RPostgreSQL)
library("dplyr")
drv = dbDriver("PostgreSQL")
ch.ds = dbConnect(drv, host='10.10.10.240', port='5432', dbname='ds', user='viewer', password='mapcview451')

#create data frame
sqlquery <- paste("select * from tabular.hous_res_sales_by_type_value_m WHERE municipal IN (" , muni,
                  ")", sep = "")

#Fetch all observations and write to file
rs <- dbSendQuery(ch.ds,sqlquery)
m<- fetch(rs, n=-1)

########################
#Adjust for inflation
#Read data and enter Variables
CPI <- read.csv("K:/DataServices/Projects/Current_Projects/Housing_Production_Plans/_all_munis_RScripts/CPI.csv", header=TRUE, sep=",")
Current_CPI <- subset(CPI$Avg, CPI$Year =='2017') #Change 2017 to reflect current year or most recent annual average CPI needed

#plug in formula to adjust for inflation = Price * (2017 CPI/ Old CPI)
m$CPI <- CPI$Avg[match(m$sale_year, CPI$Year)] #create new column that matches the sale year to the CPI Index
m$avg_adj <- (m$avg_price * (Current_CPI / m$CPI)) #plug in formula for adjusting for inflation for average price
m$q25_adj <- (m$q25_price * (Current_CPI / m$CPI)) #Adjust for inflation 25 Percentile sale price 
m$med_adj <- (m$med_price * (Current_CPI / m$CPI)) #Adjust for inflation median sale price
m$q75_adj <- (m$q75_price * (Current_CPI / m$CPI)) #Adjust for inflation 75 Percentile sale price
m$min_adj <- (m$min_price * (Current_CPI / m$CPI)) #Adjust for inflation Min sale price
m$max_adj <- (m$max_price * (Current_CPI / m$CPI)) #Adjust for inflation Max sale price


#Change column names

names(m) <- c("Seq_ID", "Municipal ID",
              "Municipality",
              "Sales Filing Year",
              "Property Use Code",
              "Residential Type",
              "Count of All Residential Sales",
              "Count of Residential Sales used in Price Calculations",
              "Average (mean) price",
              "25th Percentile Price",
              "Median (50th Percentile) Price",
              "75th Percentile Price",
              "Minimum Price",
              "Maximum Price",
              "CPI Index",
              "Average (mean) Price (Adjusted)",
              "25th Percentile Price (Adjusted)",
              "Median (50th Percentile) Price (Adjusted)",
              "75th Percentile Price (Adjusted)",
              "Minimum Price (Adjusted)",
              "Maximum Price (Adjusted)" 
)

#export data as spreadsheet
setwd(outtablepath)
write.csv(m, outtable, row.names = FALSE)



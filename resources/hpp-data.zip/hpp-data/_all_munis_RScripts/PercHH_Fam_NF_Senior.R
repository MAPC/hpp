#enter town name here:
muni <- ("'Malden', 'Everett', 'Lynn', 'Quincy', 'Revere','Salem','Somerville'")
years <- '2012-16'

#enter file name with extension here:
outtable <- paste("HH_PercFamily_NF_Seniors_2012_2016.csv")
outtablepath <- "K:/DataServices/Projects/Current_Projects/Housing_Production_Plans/Malden HPP/Data/Output/"

#read data in from SDE
library(RPostgreSQL)
drv = dbDriver("PostgreSQL")
ch.ds = dbConnect(drv, host='10.10.10.240', port='5432', dbname='ds', user='viewer', password='mapcview451')

#create data frame for medianhhincome
sqlquery <- paste("select muni_id, municipal, years, hh, fam_hh, nfam_hh, hh_65o
                  from tabular.hous_hh_type_size_by_seniors_m WHERE municipal IN 
                  (" , muni,
                  ") AND years = '2012-2016'", sep = "")

rs <- dbSendQuery(ch.ds,sqlquery)
m<- fetch(rs, n=-1)

# Create Column for Percentage of Households that are Family
m["perc_fam"] <- (m$fam_hh/m$hh)*100

# Create Column for Percentage of Households that are Nonfamily
m["perc_nfam"] <- (m$nfam_hh/m$hh)*100

# Create Column for Percentage of Households with People 65 years and over
m["perc_65o"] <- (m$hh_65o/m$hh)*100


names(m) <- c("Muni ID", "Municipality", "Census Years", "Households", "Family Households", "Nonfamily Households", 
              "Households with One or More People 65 years and over", "Percent Family Households", "Percent Nonfamily Households", 
              "Percent of Households with One or More People 65 years and over" )

#export data as spreadsheet
setwd(outtablepath)
write.csv(m, outtable, row.names = FALSE)







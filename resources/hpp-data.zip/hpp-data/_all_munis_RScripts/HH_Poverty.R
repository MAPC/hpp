#enter town name here:
muni <- ("'Middleton','Topsfield', 'Danvers', 'Peabody', 'Lynnfield', 'North Reading', 'North Andover', 'Boxford', 'Andover', 'Melrose'")
years <- '2012-16'

#enter file name with extension here:
outtable <- paste("HH_Poverty.csv")

#read data in from SDE
library(RPostgreSQL)
drv = dbDriver("PostgreSQL")
ch.ds = dbConnect(drv, host='10.10.10.240', port='5432', dbname='ds', user='dsviewer', password='dsview933')
ch.gisdata = dbConnect(drv, host='10.10.10.240', port='5432', dbname='gisdata', user='dsviewer', password='dsview933')

#create data frame
sqlquery <- paste("select muni_id, municipal, acs_year, hh, hh_me, pov_hh,
                  pov_hhme,
                  pov_f,
                  pov_fme,
                  pov_nf,
                  pov_nfme,
                  pov_hh_p,
                  pov_hhmep,
                  pov_f_p,
                  pov_fmep,
                  pov_nf_p,
                  pov_nfmep
                  from tabular.b17017_poverty_by_hh_type_acs_m WHERE municipal IN (" , muni,
                  ") AND acs_year = '2012-16'", sep = "")

m <- fetch(dbSendQuery(ch.ds, sqlquery, n = -1))


names(m) <- c("Muni ID", "Municipality", "ACS Years","Households",
              "Households; Margin of Error",
              "Households in Poverty",
              "Households in Poverty; Margin of Error",
              "Family households in Poverty",
              "Family households in Poverty; Margin of Error",
              "Nonfamily households in Poverty",
              "Nonfamily households in Poverty; Margin of Error",
              "% Households in Poverty",
              "% Households in Poverty; Margin of Error",
              "% Family households in Poverty",
              "% Family households in Poverty; Margin of Error",
              "% Nonfamily households in Poverty",
              "% Nonfamily households in Poverty; Margin of Error"
              
             )


#export data as spreadsheet
outtablepath <- paste("K:/DataServices/Projects/Current_Projects/Housing_Production_Plans/Middleton/Data/Tabular/", outtable, sep = '')
write.csv(m, outtablepath)

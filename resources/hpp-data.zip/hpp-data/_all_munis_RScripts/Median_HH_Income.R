#enter town name here:
muni <- ("'Malden', 'Everett', 'Lynn', 'Quincy', 'Revere','Salem','Somerville'")
years <- '2012-16'

#enter file name with extension here:
outtable <- paste("MedianHHIncomebyFamilyType_2012-2016.csv")
outtablepath <- "K:/DataServices/Projects/Current_Projects/Housing_Production_Plans/Malden HPP/Data/Output/"


#read data in from SDE
library(RPostgreSQL)
drv = dbDriver("PostgreSQL")
ch.ds = dbConnect(drv, host='10.10.10.240', port='5432', dbname='ds', user='viewer', password='mapcview451')

#create data frame for medianhhincome
sqlquery <- paste("select muni_id, municipal, acs_year, mhi, mhi_me, mhi_f, mhi_f_me, mhi_nf, mhi_nf_me
                  from tabular.b19013_b19113_b19202_mhi_fam_acs_m WHERE municipal IN (" , muni,
                  ") AND acs_year = '2012-16'", sep = "")

#Fetch all observations and write to file
rs <- dbSendQuery(ch.ds,sqlquery)
m<- fetch(rs, n=-1)

names(m) <- c("Muni ID", "Municipality", "ACS Years", "Median household income",
              "Median household income; Margin of Error",
              "Median family household income",
              "Median family household income; Margin of Error",
              "Median nonfamily household income",
              "Median nonfamily household income; Margin of Error")

#export data as spreadsheet
setwd(outtablepath)
write.csv(m, outtable, row.names = FALSE)
#enter town name here:
muni <- ("'Middleton','Topsfield', 'Danvers', 'Peabody', 'Lynnfield', 'North Reading', 'North Andover', 'Boxford', 'Andover', 'Melrose'")
years <- '2012-16'

#enter file name with extension here:
outtable <- paste("HousingUnitDemandProjections.csv")

#read data in from SDE
library(RPostgreSQL)
drv = dbDriver("PostgreSQL")
ch.ds = dbConnect(drv, host='10.10.10.240', port='5432', dbname='ds', user='dsviewer', password='dsview933')
ch.gisdata = dbConnect(drv, host='10.10.10.240', port='5432', dbname='gisdata', user='dsviewer', password='dsview933')

#create data frame
sqlquery <- paste("select*
                  from tabular.hous_projections_hu_demand_by_age_m WHERE municipal IN (" , muni,
                  ")", sep = "")

m <- fetch(dbSendQuery(ch.ds, sqlquery, n = -1))


names(m) <- c("Seq_ID", "Municipal ID", "Municipality",
              "Age Groups",
              "Households in 2020 based on Status Quo scenario",
              "Households in 2020 based on Stronger Region scenario",
              "Type of Tenure",
              "Change in Projected Housing Units 2010-2020 based on Status Quo Scenario",
              "Change in Projected Housing Units 2010-2020 based on Stronger Region Scenario"
              
)
              
#export data as spreadsheet
outtablepath <- paste("K:/DataServices/Projects/Current_Projects/Housing_Production_Plans/Middleton/Data/Tabular/", outtable, sep = '')
write.csv(m, outtablepath)

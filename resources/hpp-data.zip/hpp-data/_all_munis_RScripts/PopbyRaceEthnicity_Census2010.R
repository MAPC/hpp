#enter town name here:
muni <- ("'Malden', 'Everett', 'Lynn', 'Quincy', 'Revere','Salem','Somerville'")


#enter file name with extension here:
outtable <- paste("PopbyRaceEthnicity_Census2010.csv")
outtablepath <- "K:/DataServices/Projects/Current_Projects/Housing_Production_Plans/Malden HPP/Data/Output/"

#read data in from SDE
library(RPostgreSQL)
drv = dbDriver("PostgreSQL")
ch.ds = dbConnect(drv, host='10.10.10.240', port='5432', dbname='ds', user='viewer', password='mapcview451')


#create data frame 
sqlquery <- paste("select * from tabular.demo_race_ethnicity_m  WHERE municipal IN (" , muni,
                  ") AND years = '2010'", sep = "")

rs <- dbSendQuery(ch.ds,sqlquery)
m<- fetch(rs, n=-1)

names(m) <- c("Seq ID",
              "Municipal ID",
              "Municipality",
              "Census Logical Record Number",
              "Unique Geographic ID",
              "Census Year",
              "Total Population",
              "Non-Hispanic White alone",
              "Non-Hispanic Black or African American alone",
              "Non-Hispanic American Indian and Alaska Native alone",
              "Non-Hispanic Asian alone or Non-Hispanic Native Hawaiian and Other Pacific Islander alone",
              "Non-Hispanic Asian alone",
              "Non-Hispanic Native Hawaiian and Other Pacific Islander alone",
              "Non-Hispanic Some Other Race alone",
              "Non-Hispanic Two or More Races",
              "Hispanic or Latino",
              "% Non-Hispanic White alone",
              "% Non-Hispanic Black or African American alone",
              "Non-Hispanic American Indian and Alaska Native alone",
              "% Non-Hispanic Asian alone or Non-Hispanic Native Hawaiian and Other Pacific Islander alone",
              "% Non-Hispanic Asian alone",
              "% Non-Hispanic Native Hawaiian and Other Pacific Islander alone",
              "% Non-Hispanic Some Other Race alone",
              "% Non-Hispanic Two or More Races",
              "%Hispanic or Latino"
              
)

#export data as spreadsheet
setwd(outtablepath)
write.csv(m, outtable, row.names = FALSE)







#enter town name here:
muni <- c('NORTH READING')
towns <- data.frame(muni)

#load libraries
library("dplyr")
library("reshape")

#enter file name with extension here:
outtable <- paste("RentalListings_2017q4-2018q2.csv")
outtablepath <- "K:/SG Land Use/Planning Projects by Municipality/North Reading/North Reading Master Plan 2017 2018/Housing Element/"


#Read csv files of rental listingslistings
RL_2017q4 <- read.csv("K:/DataServices/Projects/Current_Projects/rental_listings_research/data/output/output_2017q4/listings_muni_summary_quarterly_2017_q4_20180408.csv", header=TRUE, sep=",")
RL_2018q1 <- read.csv("K:/DataServices/Projects/Current_Projects/rental_listings_research/data/output/output_2018q1/listings_muni_summary_quarterly_2018_q1_20180428.csv",
                      header=TRUE, sep=",")
RL_2018q2 <- read.csv("K:/DataServices/Projects/Current_Projects/rental_listings_research/data/output/output_2018q2/listings_muni_summary_quarterly_2018_q2_20180726.csv", 
                      header=TRUE, sep=",")

#Subset dataframes by muni
RentalListings_1 <- subset(RL_2018q2, muni %in% towns$muni)
RentalListings_2 <- subset(RL_2018q1, muni %in% towns$muni)
RentalListings_3 <- subset(RL_2017q4, muni %in% towns$muni)

#merge all dataframes into one
RentalListings <- do.call("rbind", list(RentalListings_1,RentalListings_2, RentalListings_3))

#export data as spreadsheet
setwd(outtablepath)
write.csv(RentalListings, outtable, row.names = FALSE)

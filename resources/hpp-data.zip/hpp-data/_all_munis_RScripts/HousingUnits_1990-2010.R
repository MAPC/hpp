#enter town name here:
muni <- ("'Malden', 'Everett', 'Lynn', 'Quincy', 'Revere','Salem','Somerville'")
years <- '2012-16'

#enter file name with extension here:
outtable <- paste("HousingUnits_1990-2010.csv")
outtablepath <- "K:/DataServices/Projects/Current_Projects/Housing_Production_Plans/Malden HPP/Data/Output/"


#read data in from SDE
library(RPostgreSQL)
drv = dbDriver("PostgreSQL")
ch.ds = dbConnect(drv, host='10.10.10.240', port='5432', dbname='ds', user='viewer', password='mapcview451')

#create data frame
sqlquery <- paste("select * from tabular.hous_housing_units_90_10_m")

#Fetch all observations and write to file
rs <- dbSendQuery(ch.ds,sqlquery)
m<- fetch(rs, n=-1)
              

names(m) <- c("Municipal ID",
              "Municipality",
              "Housing Units, 1990",
              "Occupied Housing Units, 1990",
              "Owner-occupied Housing Units, 1990",
              "Renter-occupied Housing Units, 1990",
              "Vacant Housing Units, 1990",
              "Housing Units, 2000",
              "Occupied Housing Units, 2000",
              "Owner-occupied Housing Units, 2000",
              "Renter-occupied Housing Units, 2000",
              "Vacant Housing Units, 2000",
              "Housing Units, 2010",
              "Occupied Housing Units, 2010",
              "Owner-occupied Housing Units, 2010",
              "Renter-occupied Housing Units, 2010",
              "Vacant Housing Units, 2010",
              "% Owner-occupied Housing Units, 1990",
              "% Renter-occupied Housing Units, 1990",
              "% Vacant Housing Units, 1990",
              "% Owner-occupied Housing Units, 2000",
              "% Renter-occupied Housing Units, 2000",
              "% Vacant Housing Units, 2000",
              "% Owner-occupied Housing Units, 2010",
              "% Renter-occupied Housing Units, 2010",
              "% Vacant Housing Units, 2010"
              )

#export data as spreadsheet
setwd(outtablepath)
write.csv(m, outtable, row.names = FALSE)


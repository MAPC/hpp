#enter town name here:
muni <- ("'Middleton','Topsfield', 'Danvers', 'Peabody', 'Lynnfield', 'North Reading', 'North Andover', 'Boxford', 'Andover', 'Melrose'")


#enter file name with extension here:
outtable <- paste("SubsidizedHousingInventory.csv")

#read data in from SDE
library(RPostgreSQL)
drv = dbDriver("PostgreSQL")
ch.ds = dbConnect(drv, host='10.10.10.240', port='5432', dbname='ds', user='dsviewer', password='dsview933')
ch.gisdata = dbConnect(drv, host='10.10.10.240', port='5432', dbname='gisdata', user='dsviewer', password='dsview933')

#create data frame
sqlquery <- paste("select *
                  from tabular.hous_shi_m WHERE municipal IN (" , muni,
                  ") AND shi_date = '2017-09'", sep = "")

m <- fetch(dbSendQuery(ch.ds, sqlquery, n = -1))

#Adjust for inflation

names(m) <- c("Seq_ID", "Municipal ID",
              "Municipaity",
              "Housing Unit Year",
              "Date of Inventory",
              "Housing Units",
              "Total Development Units",
              "Subsidized Housing Inventory",
              "% Subsidized Housing Inventory" )


#export data as spreadsheet
outtablepath <- paste("K:/DataServices/Projects/Current_Projects/Housing_Production_Plans/Middleton/Data/Tabular/", outtable, sep = '')
write.csv(m, outtablepath)
